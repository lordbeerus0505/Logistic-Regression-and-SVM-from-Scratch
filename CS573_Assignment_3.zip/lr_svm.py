import sys
import pandas as pd

"""
Created on Mon Apr 17 11:10:54 2017
@author: pickus
"""
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import style
style.use('ggplot')

class LogisticRegression(object):    
    """LogisticRegression 
    
    Parameters
    ------------
    learningRate : float, optional
        Constant by which updates are multiplied (falls between 0 and 1). Defaults to 0.01.
     
    numIterations : int, optional
        Number of passes (or epochs) over the training data. Defaults to 10.
    
    penalty : None or 'L2'
        Option to perform L2 regularization. Defaults to None.
    
    Attributes
    ------------
    weights : 1d-array, shape = [1, 1 + n_features]
        Weights after training phase
        
    iterationsPerformed : int
        Number of iterations of gradient descent performed prior to hitting tolerance level
        
    costs : list, length = numIterations
        Value of the log-likelihood cost function for each iteration of gradient descent
        
    References
    ------------
    https://en.wikipedia.org/wiki/Logistic_regression
    https://en.wikipedia.org/wiki/Regularization_(mathematics)
    
    """
    
    def __init__(self, learningRate, numIterations = 10, penalty = None, C = 0.01):
        
        self.learningRate = learningRate
        self.numIterations = numIterations
        self.penalty = penalty
        self.C = C
        
    def train(self, X_train, y_train, tol = 10 ** -4):
        """Fit weights to the training data
        
        Parameters
        -----------
        X_train : {array-like}, shape = [n_samples, n_features]
            Training data to be fitted, where n_samples is the number of 
            samples and n_features is the number of features. 
            
        y_train : array-like, shape = [n_samples,], values = 1|0
            Labels (target values). 
        tol : float, optional
            Value indicating the weight change between epochs in which
            gradient descent should terminated. Defaults to 10 ** -4
        Returns:
        -----------
        self : object
        
        """
        # +1 for the bias term, w0 in weight vector
        tolerance = tol * np.ones([1, np.shape(X_train)[1] + 1])
        # import pdb; pdb.set_trace()
        # print(tolerance)



        self.weights = np.zeros(np.shape(X_train)[1] + 1) 
        # self.weights = np.random.rand(np.shape(X_train)[1] + 1) 
        X_train = np.c_[np.ones([np.shape(X_train)[0], 1]), X_train]
        self.costs = []
        # import pdb; pdb.set_trace()
        for i in range(self.numIterations):
            print('Iteration %s completed ... '%i)
            # import pdb; pdb.set_trace()
            z = np.dot(X_train, self.weights)
            errors = y_train - logistic_func(z)
            if self.penalty is not None:                
                delta_w = self.learningRate * (self.C * np.dot(errors, X_train) + np.sum(self.weights))  
            else:
                delta_w = self.learningRate * np.dot(errors, X_train)
                

            # for i in range(len(delta_w)):
            #     if delta_w[i] == 0:
            #         delta_w[i]  = 10**-6
            self.iterationsPerformed = i
            # import pdb; pdb.set_trace()
            # print(abs(delta_w)-tolerance)
            if np.all(abs(delta_w) >= tolerance): 
                #weight update
                self.weights += delta_w                                
                #Costs
                if self.penalty is not None:
                    self.costs.append(reg_logLiklihood(X_train, self.weights, y_train, self.C))
                else:
                    self.costs.append(logLiklihood(z, y_train))
            else:
                break
            
        return self
                    
    def predict(self, X_test, pi = 0.5):
        """predict class label 
        
        Parameters
        ------------
        X_test : {array-like}, shape = [n_samples, n_features]
            Testing data, where n_samples is the number of samples
            and n_features is the number of features. n_features must
            be equal to the number of features in X_train.
            
        pi : float, cut-off probability, optional
            Probability threshold for predicting positive class. Defaults to 0.5.
        
        Returns
        ------------
        predictions : list, shape = [n_samples,], values = 1|0
            Class label predictions based on the weights fitted following 
            training phase.
        
        probs : list, shape = [n_samples,]
            Probability that the predicted class label is a member of the 
            positive class (falls between 0 and 1).
        
        """        
        z = self.weights[0] + np.dot(X_test, self.weights[1:])        
        probs = np.array([logistic_func(i) for i in z])
        predictions = np.where(probs >= pi, 1, 0)
       
        return predictions, probs
        
    def performanceEval(self, predictions, y_test):
        """Computer binary classification performance metrics
        
        Parameters
        -----------
        predictions : list, shape = [n_samples,], values = 1|0
            Class label predictions based on the weights fitted following 
            training phase. 
        
        y_test : list, shape = [n_samples,], values = 1|0
            True class labels
        
        Returns
        -----------
        performance : dict
            Accuracy, sensitivity (recall), specificity, postitive predictive 
            value (PPV, precision), negative predictive value (NPV), false 
            negative rate (FNR, "miss rate"), false positive rate (FPR, "fall out")
        """        
        count = 0
        diff = np.subtract(predictions, y_test)
        # import pdb; pdb.set_trace()

        # for i in range(len(predictions)):
            # if predictions[i] != y_test[i]:
            #     print(predictions[i], y_test[i])
        return np.sum(np.abs(diff))/ len(predictions)
        #Initialize
        # TP, TN, FP, FN, P, N = 0, 0, 0, 0, 0, 0
        
        # for idx, test_sample in enumerate(y_test):
            
        #     if predictions[idx] == 1 and test_sample == 1:
        #         TP += 1       
        #         P += 1
        #     elif predictions[idx] == 0 and test_sample == 0:                
        #         TN += 1
        #         N += 1
        #     elif predictions[idx] == 0 and test_sample == 1:
        #         FN += 1
        #         P += 1
        #     elif predictions[idx] == 1 and test_sample == 0:
        #         FP += 1
        #         N += 1
            
        # accuracy = (TP + TN) / (P + N)                
        # sensitivity = TP / P        
        # specificity = TN / N        
        # PPV = TP / (TP + FP)        
        # NPV = TN / (TN + FN)        
        # FNR = 1 - sensitivity        
        # FPR = 1 - specificity
        
        # performance = {'Accuracy': accuracy, 'Sensitivity': sensitivity,
        #                'Specificity': specificity, 'Precision': PPV,
        #                'NPV': NPV, 'FNR': FNR, 'FPR': FPR}        
      
        # return performance

def logistic_func(z):   
    """Logistic (sigmoid) function, inverse of logit function
    
    Parameters:
    ------------
    z : float
        linear combinations of weights and sample features
        z = w_0 + w_1*x_1 + ... + w_n*x_n
    
    Returns:
    ---------
    Value of logistic function at z
    
    """
    return 1 / (1 + np.exp(-z))  
    
def logLiklihood(z, y):
    """Log-liklihood function (cost function to be minimized in logistic
    regression classification)
    
    Parameters
    -----------
    z : float
        linear combinations of weights and sample features
        z = w_0 + w_1*x_1 + ... + w_n*x_n
        
    y : list, values = 1|0
        target values
    
    Returns
    -----------
    Value of log-liklihood function with parameter z and target value y
    """
    return -1 * np.sum((y * np.log(logistic_func(z))) + ((1 - y) * np.log(1 - logistic_func(z))))
    
def reg_logLiklihood(x, weights, y, C):
    """Regularizd log-liklihood function (cost function to minimized in logistic
    regression classification with L2 regularization)
    
    Parameters
    -----------
    x : {array-like}, shape = [n_samples, n_features + 1]
        feature vectors. Note, first column of x must be
        a vector of ones.
    
    weights : 1d-array, shape = [1, 1 + n_features]
        Coefficients that weight each samples feature vector
        
    y : list, shape = [n_samples,], values = 1|0
        target values
        
    C : float
        Regularization parameter. C is equal to 1/lambda    
    
    Returns
    -----------
    Value of regularized log-liklihood function with the given feature values,
    weights, target values, and regularization parameter
     
    """
    z = np.dot(x, weights) 
    reg_term = (1 / (2 * C)) * np.dot(weights.T, weights)
    
    return -1 * np.sum((y * np.log(logistic_func(z))) + ((1 - y) * np.log(1 - logistic_func(z)))) + reg_term

def lr(trainingSet, testSet):
    y_train = trainingSet['decision']
    X_train = trainingSet.drop(['decision'], axis=1)
    
    # import pdb; pdb.set_trace()

    LR = LogisticRegression(learningRate = 0.001, numIterations = 200, penalty = 'L2', C = 0.01)  
    LR.train(X_train, y_train, tol = 10 ** -6)

    # import pdb; pdb.set_trace()

    y_test = testSet['decision']
    X_test = testSet.drop(['decision'], axis=1)

    predictions, probs = LR.predict(X_train, 1)
    performance = svmPerformance(predictions, y_train)
    print('Training Accuracy LR: %.5f'%performance)

    predictions, probs = LR.predict(X_test, 1)
    performance = svmPerformance(predictions, y_test)
    print('Test Accuracy LR: %.5f'%performance)

def svmPerformance(prediction, actual):
    diff = np.subtract(prediction, actual)
    return 1- np.sum(np.abs(diff))/len(prediction)
    # total = len(prediction)
    # count = 0
    # for i in range(total):
    #     if prediction[i] == actual[i]:
    #         count +=1
    # return float(count)/total

def main(trainingDataFilename, testDataFilename, modelIdx):
    trainingSet = pd.read_csv(trainingDataFilename)
    testSet = pd.read_csv(testDataFilename)
    y_train = trainingSet['decision']
    X_train = trainingSet.drop(['decision'], axis=1)
    
    """ from sklearn.linear_model import LogisticRegression
    logisticReg = LogisticRegression(random_state=0).fit(X_train, y_train)
    result = logisticReg.predict(X_train)
    print('The LogReg accuracy was:', svmPerformance(result, y_train))

    from sklearn import svm
    clf = svm.SVC()
    clf.fit(X_train, y_train) """
    
    y_test = testSet['decision']
    X_test = testSet.drop(['decision'], axis=1)
    # result = clf.predict(X_train)
    # import pdb; pdb.set_trace()
    # print(svmPerformance(result, y_train))
    # print(len(trainingSet.columns))
    if modelIdx == '1':
        lr(trainingSet, testSet)
    else:
        svm(trainingSet, testSet)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3])